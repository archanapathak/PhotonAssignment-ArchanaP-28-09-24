package com.EcommApp.PhotonTest_Archana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotonTestArchanaApplicationTests {

	@Test
	void contextLoads() {
	}

}
