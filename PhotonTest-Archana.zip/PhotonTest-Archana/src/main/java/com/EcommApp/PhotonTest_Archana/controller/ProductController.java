package com.EcommApp.PhotonTest_Archana.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.EcommApp.PhotonTest_Archana.dto.ProductRequest;
import com.EcommApp.PhotonTest_Archana.entity.Product;
import com.EcommApp.PhotonTest_Archana.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService productService;
	
	@PostMapping("/addproduct")
	public ResponseEntity<Product> addProduct( ProductRequest productRequest){
		
		Product product = new Product();
		product.setName(productRequest.getName());
		
		return new ResponseEntity<Product>(product, HttpStatus.CREATED);
		
	}
	
	

}
