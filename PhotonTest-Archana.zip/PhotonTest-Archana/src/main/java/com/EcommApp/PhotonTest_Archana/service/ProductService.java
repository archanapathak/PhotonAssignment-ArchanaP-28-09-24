package com.EcommApp.PhotonTest_Archana.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.EcommApp.PhotonTest_Archana.dto.ProductRequest;
import com.EcommApp.PhotonTest_Archana.entity.Product;
import com.EcommApp.PhotonTest_Archana.repository.ProductRepository;

@Service
public class ProductService {
	@Autowired
	ProductRepository productRepository;
	
	public Product addProduct(ProductRequest productRequest) {
		Product product = new Product();
		product.setName(productRequest.getName());
		product.setDescription(productRequest.getDescription());
		product.setPrice(productRequest.getPrice());
		product.setImageUrl(productRequest.getImageUrl());
		return productRepository.save(product);
	}
	
	
	public  List<Product> listAllProduct() {
		
		return productRepository.findAll();
		
	}

}
