package com.EcommApp.PhotonTest_Archana.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.EcommApp.PhotonTest_Archana.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {

}
