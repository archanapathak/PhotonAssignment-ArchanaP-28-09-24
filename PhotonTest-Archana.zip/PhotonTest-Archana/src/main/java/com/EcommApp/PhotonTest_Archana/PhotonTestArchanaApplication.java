package com.EcommApp.PhotonTest_Archana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotonTestArchanaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotonTestArchanaApplication.class, args);
	}

}
